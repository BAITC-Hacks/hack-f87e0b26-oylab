"""Local static server: no API, secret, external requests or extra dependencies."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parent
FILES={'/':('index.html','text/html'),'/index.html':('index.html','text/html'),'/style.css':('style.css','text/css'),'/script.js':('script.js','text/javascript'),'/hackathon-dataset-anonymized.jsonl':('hackathon-dataset-anonymized.jsonl','application/x-ndjson')}
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        entry=FILES.get(self.path.split('?',1)[0])
        if not entry:
            self.send_error(404);return
        name,kind=entry
        body=(ROOT/name).read_bytes()
        self.send_response(200)
        self.send_header('Content-Type',kind+'; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        self.wfile.write(body)
if __name__=='__main__':
    port=int(os.environ.get('PORT','8000'))
    print(f'Jina: http://127.0.0.1:{port} | No API key required',flush=True)
    ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
