/* Dependency-free frontend. Local text extraction and deterministic ranking; no AI API calls. */
"use strict";

const CALENDAR = Object.freeze({ min: "2026-09-23", max: "2026-12-31" });
const LABELS = {
  "Зарубежье": "Шетел", "свадьба": "Үйлену тойы", "той": "Той",
  "корпоратив": "Корпоратив", "конференция": "Конференция", "юбилей": "Мерейтой",
  "день рождения": "Туған күн", "русский": "Орысша", "казахский": "Қазақша",
  "английский": "Ағылшынша", "Ведущий": "Жүргізуші", "Банкетный зал": "Банкет залы",
  "Подарки и сувениры": "Сыйлықтар мен кәдесыйлар", "Ведущий церемонии": "Рәсім жүргізушісі",
  "Фото и видеобудки": "Фото және бейнебудкалар", "Отель": "Қонақүй",
  "Инструменталист": "Аспапшы", "Национальный ансамбль": "Ұлттық ансамбль",
  "Танцевальный коллектив": "Би ұжымы", "Шоу-программа": "Шоу-бағдарлама",
  "Загородная площадка": "Қала сыртындағы алаң", "Лайв-бэнд": "Жанды музыка тобы"
};
// Transparent lexical relevance: Russian stems match the source descriptions.
const STEMS = {
  "свадьба": ["свад", "невест", "молодож", "бракосоч"], "той": ["той", "тоя", "тоев"],
  "корпоратив": ["корпоратив"], "конференция": ["конференц", "делов", "бизнес"],
  "юбилей": ["юбиле"], "день рождения": ["день рожд", "дня рожд", "дней рожд"],
  "Ведущий": ["ведущ", "ведени", "провожу"], "Фотограф": ["фотограф", "фотосъем", "фотосъём"],
  "Видеограф": ["видео", "съем", "съём"], "Флорист": ["флорист", "цвет"],
  "Декоратор": ["декор", "оформлен"], "Банкетный зал": ["банкет", "зал"],
  "Ведущий церемонии": ["церемони", "регистрац"], "Подарки и сувениры": ["подар", "сувенир", "мерч"],
  "Фото и видеобудки": ["фотобуд", "видеобуд", "зеркал"], "Отель": ["отель", "гостиниц"],
  "Инструменталист": ["скрип", "саксоф", "инструмент"], "Лайв-бэнд": ["музык", "групп", "бэнд"],
  "Национальный ансамбль": ["ансамбл", "национальн"], "Танцевальный коллектив": ["танц", "хореограф"],
  "Шоу-программа": ["шоу", "выступлен"], "Загородная площадка": ["загород", "природ", "террас"],
  "Ресторан": ["ресторан", "кухн"]
};
const label = value => LABELS[value] || value;
const normalize = value => String(value).trim().toLocaleLowerCase("ru-RU").replaceAll("ё", "е");
const equal = (a, b) => normalize(a) === normalize(b);
const includes = (list, value) => list.some(item => equal(item, value));
const compareText = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const money = value => new Intl.NumberFormat("kk-KZ", { maximumFractionDigits: 0 }).format(value) + " ₸";
const displayDate = value => value.split("-").reverse().join(".");
const validDate = value => /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  Number.isFinite(Date.parse(value + "T00:00:00Z")) &&
  new Date(value + "T00:00:00Z").toISOString().slice(0, 10) === value;

function parseJSONL(text) {
  const seen = new Set();
  const data = text.replace(/^\uFEFF/, "").split(/\r?\n/).flatMap((line, index) => {
    if (!line.trim()) return [];
    let p;
    try { p = JSON.parse(line); } catch { throw new Error(`JSONL: ${index + 1}-жолда JSON қатесі бар.`); }
    const fail = () => { throw new Error(`JSONL: ${index + 1}-жолдағы профиль өрістері жарамсыз.`); };
    if (!p || typeof p !== "object" || Array.isArray(p)) fail();
    for (const key of ["id", "anon_name", "city", "description"]) {
      if (typeof p[key] !== "string" || !p[key].trim()) fail();
    }
    for (const key of ["categories", "event_formats", "languages", "busy_dates"]) {
      if (!Array.isArray(p[key]) || p[key].some(v => typeof v !== "string" || !v.trim())) fail();
    }
    if (!p.categories.length || !p.event_formats.length || !p.languages.length ||
        p.busy_dates.some(v => !validDate(v)) || seen.has(p.id) ||
        !Number.isFinite(p.price_from_kzt) || p.price_from_kzt < 0 ||
        !(p.max_hours === null || (Number.isFinite(p.max_hours) && p.max_hours > 0)) ||
        typeof p.synthetic !== "boolean") fail();
    for (const key of ["city_imputed", "price_imputed"]) {
      if (p[key] !== undefined && typeof p[key] !== "boolean") fail();
    }
    seen.add(p.id);
    return [p];
  });
  if (!data.length) throw new Error("JSONL файлында профильдер жоқ.");
  return data;
}

function validateQuery(q) {
  if (![q.city, q.category, q.format].every(v => typeof v === "string" && v.trim()))
    throw new Error("Қала, іс-шара түрі және санатты таңдаңыз.");
  if (!validDate(q.date) || q.date < CALENDAR.min || q.date > CALENDAR.max)
    throw new Error("23.09.2026–31.12.2026 аралығындағы күнді таңдаңыз.");
  if (!Number.isFinite(q.budget) || q.budget < 0) throw new Error("Жарамды бюджет енгізіңіз.");
  if (q.hours !== null && (!Number.isFinite(q.hours) || q.hours <= 0))
    throw new Error("Ұзақтық нөлден үлкен болуы керек.");
}

function scoreProfile(p, q) {
  const description = normalize(p.description);
  const groups = [q.format, q.category].map(key => STEMS[key] || [key]);
  const evidence = groups.map(stems => stems.find(stem => description.includes(normalize(stem)))).filter(Boolean);
  const parts = {
    budget: q.budget === 0 ? 30 : 30 * (1 - p.price_from_kzt / q.budget),
    format: 25,
    language: q.language ? 15 : null,
    duration: q.hours !== null ? 15 : null,
    description: 15 * evidence.length / groups.length
  };
  const possible = 70 + (q.language ? 15 : 0) + (q.hours !== null ? 15 : 0);
  const rawScore = Object.values(parts).reduce((sum, n) => sum + (n ?? 0), 0) / possible * 100;
  return { profile: p, parts, possible, evidence, rawScore, score: Math.round(rawScore * 10) / 10 };
}

function recommend(data, q) {
  validateQuery(q);
  const pool = data.filter(p => equal(p.city, q.city) && includes(p.categories, q.category));
  const rejected = { busy: 0, budget: 0, format: 0, language: 0, duration: 0 };
  const eligible = pool.filter(p => {
    const reasons = {
      busy: p.busy_dates.includes(q.date),
      budget: p.price_from_kzt > q.budget,
      format: !includes(p.event_formats, q.format),
      language: Boolean(q.language) && !includes(p.languages, q.language),
      duration: q.hours !== null && p.max_hours !== null && p.max_hours < q.hours
    };
    for (const key of Object.keys(reasons)) if (reasons[key]) rejected[key]++;
    return !Object.values(reasons).some(Boolean);
  }).map(p => scoreProfile(p, q));
  eligible.sort((a, b) => b.rawScore - a.rawScore ||
    a.profile.price_from_kzt - b.profile.price_from_kzt || compareText(a.profile.id, b.profile.id));
  return { poolCount: pool.length, eligibleCount: eligible.length, rejected,
    items: eligible.slice(0, 3), outcome: !pool.length ? "no-category" : eligible.length ? "matched" : "no-match" };
}

function explanation(p, q) {
  const saving = q.budget - p.price_from_kzt;
  const budget = saving > 0 ? `бюджеттен ${money(saving)} төмен` : "бюджетке дәл келеді";
  const conditions = [`«${label(q.format)}» форматын қабылдайды`];
  if (q.language) conditions.push(`${label(q.language).toLowerCase()} жұмыс істейді`);
  if (q.hours !== null) conditions.push(p.max_hours === null
    ? "қызметі алаңда болу ұзақтығына байланысты емес"
    : `${q.hours} сағатқа сай (шегі ${p.max_hours} сағат)`);
  return `${displayDate(q.date)} күні бос, бастапқы бағасы ${money(p.price_from_kzt)} — ${budget}. ` +
    conditions.join(", ").replace(/^./u, c => c.toUpperCase()) + ".";
}

function findAlternatives(data, q) {
  const base = recommend(data, q);
  const changes = [];
  const offer = (key, value, title) => {
    const query = { ...q, [key]: value };
    const result = recommend(data, query);
    if (result.eligibleCount > 0) changes.push({ key, value, title, count: result.eligibleCount });
  };
  if (!base.eligibleCount) {
    const prices = [...new Set(data.map(p => p.price_from_kzt))].filter(v => v > q.budget).sort((a,b)=>a-b);
    for (const price of prices) {
      if (recommend(data, {...q, budget:price}).eligibleCount) {
        offer('budget',price,`Бюджетке ${money(price-q.budget)} қосу → ${money(price)}`); break;
      }
    }
    if (q.language) offer('language','',`Тіл талабын алып тастау (${label(q.language)})`);
    if (q.hours !== null) {
      const capacities=[...new Set(data.map(p=>p.max_hours))].filter(v=>v!==null&&v<q.hours&&v>0).sort((a,b)=>b-a);
      for(const hours of capacities) if(recommend(data,{...q,hours}).eligibleCount){offer('hours',hours,`Ұзақтықты ${q.hours} сағаттан ${hours} сағатқа қысқарту`);break;}
    }
    if (!base.poolCount) for(const city of [...new Set(data.map(p=>p.city))].sort(compareText)) if(city!==q.city)offer('city',city,`Қаланы ${label(city)} деп өзгерту`);
    if (!changes.length) for(const format of [...new Set(data.flatMap(p=>p.event_formats))].sort(compareText)) if(format!==q.format)offer('format',format,`Форматты «${label(format)}» деп өзгерту`);
  }
  const dates=[];
  const utc=Date.parse(q.date+'T00:00:00Z');
  for(let delta=1;delta<=7;delta++) for(const direction of [1,-1]) {
    const date=new Date(utc+delta*direction*86400000).toISOString().slice(0,10);
    if(date<CALENDAR.min||date>CALENDAR.max)continue;
    const result=recommend(data,{...q,date});
    if(result.eligibleCount)dates.push({key:'date',value:date,title:displayDate(date),count:result.eligibleCount});
  }
  return {changes:changes.slice(0,3),dates:dates.slice(0,3)};
}

function renderExtras(data, result, q) {
  const actions=document.getElementById('result-actions');
  actions.hidden=!result.items.length;
  const comparison=document.getElementById('comparison');comparison.hidden=true;comparison.replaceChildren();
  const compare=document.getElementById('compare-button');compare.setAttribute('aria-expanded','false');compare.textContent='Ұсыныстарды салыстыру';
  const table=element('table');table.append(element('caption','',`${result.items.length} ұсынысты салыстыру`));
  const head=element('thead'),headRow=element('tr');headRow.append(element('th','','Өлшем'));
  for(const item of result.items){const th=element('th','',item.profile.anon_name);th.scope='col';headRow.append(th);}
  head.append(headRow);table.append(head);
  const rows=[['Санат',p=>label(q.category)],['Қала',p=>label(p.city)],['Бастапқы баға',p=>money(p.price_from_kzt)],['Бюджет қалдығы',p=>money(q.budget-p.price_from_kzt)],['Күн',()=>displayDate(q.date)+' — бос'],['Форматтар',p=>p.event_formats.map(label).join(', ')],['Тілдер',p=>p.languages.map(label).join(', ')],['Ұзақтық шегі',p=>p.max_hours===null?'Алаңда болу уақытына тәуелсіз':p.max_hours+' сағ'],['Сипаттама',p=>p.description],['Деректер',p=>[p.synthetic?'Синтетикалық':'Анонимделген',p.price_imputed&&'бағасы толықтырылған',p.city_imputed&&'қаласы толықтырылған'].filter(Boolean).join('; ')]];
  const body=element('tbody');
  for(const [name,getValue] of rows){const tr=element('tr');const th=element('th','',name);th.scope='row';tr.append(th);for(const item of result.items)tr.append(element('td','',getValue(item.profile)));body.append(tr);}
  const scores=element('tr');const labelCell=element('th','','Score / 100');labelCell.scope='row';scores.append(labelCell);for(const item of result.items)scores.append(element('td','',item.score.toFixed(1)));body.append(scores);table.append(body);comparison.append(table);
  compare.onclick=()=>{comparison.hidden=!comparison.hidden;compare.setAttribute('aria-expanded',String(!comparison.hidden));compare.textContent=comparison.hidden?'Ұсыныстарды салыстыру':'Салыстыруды жабу';};
  document.getElementById('print-button').onclick=()=>window.print();
  const alternatives=findAlternatives(data,q);
  const showOptions=(id,items)=>{
    const target=document.getElementById(id);target.replaceChildren();
    for(const item of items){
      const box=element('div','suggestion-option');box.append(element('h4','',item.title),element('p','',`${item.count} сәйкес профиль · ең көбі 3 ұсыныс`));
      const button=element('button','secondary-button',item.key==='date'?'Осы күнді таңдау':'Өзгертіп іздеу');button.type='button';
      button.addEventListener('click',()=>{
        // Start from the last submitted query; a single explicit change is applied.
        const changed={...q,[item.key]:item.value};
        for(const key of ['city','date','category','format','budget','language','hours'])document.getElementById(key).value=changed[key]??'';
        document.getElementById('search-form').requestSubmit();
      });box.append(button);target.append(box);
    }
  };
  const suggestions=document.getElementById('suggestions');suggestions.hidden=!!result.eligibleCount;
  showOptions('suggestion-options',alternatives.changes);
  if(!result.eligibleCount&&!alternatives.changes.length)document.getElementById('suggestion-options').append(element('p','','Тексерілген бір шартты өзгерту нұсқаларынан нәтиже табылмады. Қала, санат және басқа талаптарды бірге қайта қараңыз.'));
  document.getElementById('nearby-dates').hidden=false;
  showOptions('date-options',alternatives.dates);
  if(!alternatives.dates.length)document.getElementById('date-options').append(element('p','','±7 күн ішінде қалған шарттарыңызға сай ұсыныс табылмады.'));
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text; // Dataset content never becomes HTML.
  return node;
}

function createCard(item, q, index) {
  const p = item.profile;
  const card = element("article", "card");
  const ribbon = element("div", "card-ribbon");
  ribbon.append(element("span", "rank-label", `${String(index + 1).padStart(2, "0")} / ${index === 0 ? "Ең жоғары сәйкестік" : "Сізге сәйкес"}`), element("span", "available-label", "Күні бос"));
  const top = element("div", "card-top");
  const avatar = element("div", "avatar", p.anon_name.split(/\s+/u).slice(0, 2).map(s => s[0]).join(""));
  avatar.setAttribute("aria-hidden", "true");
  const identity = element("div", "identity");
  identity.append(element("h3", "", p.anon_name), element("p", "", `${label(q.category)} · ${label(p.city)}`));
  const score = element("div", "score", item.score.toFixed(1));
  score.append(element("small", "", "score / 100"));
  const scoreTrack = element("span", "score-track");
  scoreTrack.setAttribute("aria-hidden", "true");
  const scoreFill = element("span", "score-fill");
  scoreFill.style.width = `${item.score}%`;
  scoreTrack.append(scoreFill);
  score.append(scoreTrack);
  top.append(avatar, identity, score);
  const priceRow = element("div", "price-row");
  const price = element("div", "price", money(p.price_from_kzt));
  price.append(element("small", "", "бастап"));
  priceRow.append(price, element("span", p.synthetic ? "tag synthetic" : "tag", p.synthetic ? "Синтетикалық профиль" : "Анонимделген профиль"));
  const why = element("div", "explanation");
  why.append(element("p", "explanation-title", `${String(index + 1).padStart(2, "0")} · Неліктен ұсынылды`), element("p", "", explanation(p, q)));
  const details = element("details");
  details.append(element("summary", "", "Сипаттама және score есебі"));
  details.append(element("p", "", p.description));
  const parts = element("div", "score-parts");
  const partLabels = { budget: "Бюджет", format: "Формат", language: "Тіл", duration: "Ұзақтық", description: "Сипаттама" };
  const weights = { budget: 30, format: 25, language: 15, duration: 15, description: 15 };
  for (const [key, value] of Object.entries(item.parts)) parts.append(element("span", "query-chip",
    `${partLabels[key]}: ${value === null ? "есептелмейді" : value.toFixed(1) + "/" + weights[key]}`));
  details.append(parts, element("p", "", `Жиынтық ұпай ${item.possible} мүмкін ұпайдан 100-ге келтірілген. Сипаттамадағы сәйкес сөз түбірлері: ${item.evidence.join(", ") || "табылмады"}.`));
  const flags = [p.city_imputed && "қаласы", p.price_imputed && "бағасы"].filter(Boolean);
  if (flags.length) details.append(element("p", "", `Датасетті дайындау кезінде ${flags.join(" және ")} толықтырылған.`));
  const budgetBox=element('div','budget-box');
  const used=q.budget===0?0:Math.min(100,Math.round(p.price_from_kzt/q.budget*100));
  const track=element('div','budget-track');track.setAttribute('aria-hidden','true');const fill=element('span');fill.style.width=used+'%';track.append(fill);
  budgetBox.append(element('p','',`Бюджет: ${money(q.budget)} · бағасы ${used}%`),track,element('strong','',`${money(q.budget-p.price_from_kzt)} қалады`));
  card.append(ribbon, top, priceRow, budgetBox, why, details);
  return card;
}

function render(result, q) {
  const results = document.getElementById("results");
  const status = document.getElementById("status");
  const diagnostics = document.getElementById("diagnostics");
  status.className = "status";
  results.replaceChildren();
  document.getElementById("result-count").textContent = `${result.items.length} / 3`;
  const summary = document.getElementById("query-summary");
  summary.replaceChildren(...[label(q.city), displayDate(q.date), label(q.format), label(q.category), money(q.budget),
    q.language && label(q.language), q.hours !== null && `${q.hours} сағат`].filter(Boolean).map(text => element("span", "query-chip", text)));
  if (result.items.length) {
    status.textContent = `${result.poolCount} профиль тексерілді · ${result.eligibleCount} сәйкес · ең көбі 3 ұсыныс`;
    results.append(...result.items.map((item, index) => createCard(item, q, index)));
  } else {
    status.textContent = "Сұраныс тексерілді. Сәйкес ұсыныс табылмады.";
    const empty = element("div", "empty");
    empty.append(element("div", "empty-icon", "⌕"), element("h3", "", result.outcome === "no-category"
      ? "Бұл қалада мұндай санат жоқ" : "Мердігерлер бар, бірақ шарттарға сай емес"),
      element("p", "", result.outcome === "no-category"
        ? `${label(q.city)} қаласында «${label(q.category)}» санатындағы профиль жоқ; басқа қаланы немесе санатты таңдаңыз.`
        : "Төмендегі себептерді қарап, күнді, бюджетті немесе қосымша шарттарды өзгертіңіз."));
    results.append(empty);
  }
  diagnostics.replaceChildren();
  diagnostics.hidden = result.poolCount === 0;
  if (result.poolCount) {
    diagnostics.append(element("p", "", result.eligibleCount < 3
      ? `Неліктен 3-тен аз? Осы қала мен санатта ${result.poolCount} профиль бар, барлық шартқа ${result.eligibleCount} профиль сай.`
      : `${displayDate(q.date)} күнгі іріктеу себептері`));
    const reasons = { busy: "Сол күні бос емес", budget: "Бюджетке сыймайды", format: "Іс-шара форматы сәйкес емес", language: "Тіл сәйкес емес", duration: "Ұзақтық сәйкес емес" };
    const list = element("ul");
    for (const [key, count] of Object.entries(result.rejected)) if (count) list.append(element("li", "", `${reasons[key]}: ${count} профиль`));
    if (list.childElementCount) {
      diagnostics.append(list, element("small", "", "Бір профиль бірнеше шартқа сәйкес келмеуі мүмкін; сандар қабаттасады."));
    } else diagnostics.append(element("p", "", "Осы қала мен санаттағы барлық профиль шарттарға сай."));
  }
}

// Bilingual deterministic extraction; no remote model or secret is used.
const LOCAL_ALIASES = {
  city: { 'Алматы':['алматы','алмата','алмате'], 'Астана':['астана','астане','астану','нур-султан'], 'Зарубежье':['шетел','зарубеж'] },
  format: { 'свадьба':['үйлену той','свадьб','свадеб'], 'той':['той'], 'корпоратив':['корпоратив'], 'конференция':['конференц'], 'юбилей':['юбиле','мерейтой'], 'день рождения':['день рождения','дня рождения','туған күн','туғанкүн'] },
  category: { 'Ведущий':['жүргізуші','ведущий','ведущего','ведущая','ведущую','тамада'], 'Фотограф':['фотограф'], 'Видеограф':['видеограф','видеооператор'], 'Флорист':['флорист'], 'Декоратор':['декоратор'], 'Подарки и сувениры':['сыйлық','кәдесый','подарки','подарков','сувенир'], 'Ведущий церемонии':['рәсім жүргізуші','ведущий церемонии','ведущего церемонии','церемониймейстер'], 'Фото и видеобудки':['фотобуд','видеобуд','фото және бейнебуд'], 'Банкетный зал':['банкетный зал','банкетного зала','банкет зал','банкет залы'], 'Отель':['отель','отеля','қонақүй'], 'Инструменталист':['инструменталист','аспапшы','скрипач','саксофонист'], 'Лайв-бэнд':['лайв-бэнд','лайв бэнд','кавер групп','жанды музыка'], 'Национальный ансамбль':['национальный ансамбль','ұлттық ансамбль'], 'Танцевальный коллектив':['танцевальный коллектив','би ұжымы','биші'], 'Шоу-программа':['шоу-программ','шоу бағдарлам','шоу-бағдарлам'], 'Загородная площадка':['загородная площадка','загородную площадку','қала сыртындағы алаң'], 'Ресторан':['ресторан'] },
  language: { 'казахский':['қазақша','қазақ тіл','казахск'], 'русский':['орысша','орыс тіл','русск'], 'английский':['ағылшын','английск'] }
};
const MONTHS = ['қаңтар|январ','ақпан|феврал','наурыз|март','сәуір|апрел','мамыр|мая|май','маусым|июн','шілде|июл','тамыз|август','қыркүйек|сентябр','қазан|октябр','қараша|ноябр','желтоқсан|декабр'];
const FIELD_NAMES = { city:'Қала', date:'Күн', format:'Формат', category:'Санат', budget:'Бюджет', language:'Тіл', hours:'Ұзақтық' };
function parseLocalRequest(message, previous = {}) {
  const q = { city:null,date:null,format:null,category:null,budget:null,language:null,hours:null,...previous.criteria };
  const issues = {...previous.issues};
  const text = normalize(message);
  let recognized = 0;
  const notes = [];
  const set = (key,value) => { q[key]=value;delete issues[key];recognized++; };
  const problem = (key,message) => {q[key]=null;issues[key]=message;recognized++;};
  for (const [key, choices] of Object.entries(LOCAL_ALIASES)) {
    let hits = Object.entries(choices).filter(([, aliases]) => aliases.some(alias => text.includes(alias))).map(([value])=>value);
    if (key==='format' && hits.includes('свадьба')) hits=hits.filter(v=>v!=='той');
    if (key==='format' && hits.includes('юбилей')) hits=hits.filter(v=>v!=='той');
    if (key==='category' && hits.includes('Ведущий церемонии')) hits=hits.filter(v=>v!=='Ведущий');
    if (hits.length===1) set(key,hits[0]);
    else if(hits.length>1) problem(key,`${FIELD_NAMES[key]}: бір ғана нұсқаны жазыңыз (${hits.map(label).join(', ')}).`);
  }
  // Explicit removal of optional requirements.
  if (/тіл.*(?:маңызды емес|кез келген)|кез келген тіл|любой язык|язык.*(?:не важен|неважен)/u.test(text)) set('language',null);
  if (/ұзақтық.*(?:маңызды емес|алып таста)|без ограничения по времени|длительность.*(?:не важна|убрать)/u.test(text)) set('hours',null);
  if (/шымкент|қарағанды|караганда|ақтөбе|актобе|атырау|павлодар|тараз|көкшетау|кокшетау|семей|орал|костанай|қостанай|ақтау|актау/u.test(text)) problem('city','Каталогта тек Алматы, Астана және Шетел бар. Қаланы осы нұсқалардан таңдаңыз.');
  const dates=[];
  const datePattern=/(\d{4})-(\d{2})-(\d{2})|\b(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?/gu;
  for(const m of text.matchAll(datePattern)) {
    if(!m[1]&&!m[6]&&/^\s*(?:сағ|час|ч\b|млн|мың|тыс|миллион|теңге|тенге|₸|kzt)/u.test(text.slice(m.index+m[0].length)))continue;
    let year=m[1] || m[6] || '2026';if(year.length===2)year='20'+year;
    dates.push(`${year}-${(m[2]||m[5]).padStart(2,'0')}-${(m[3]||m[4]).padStart(2,'0')}`);
    if(!m[1]&&!m[6]) notes.push('Жыл көрсетілмегендіктен 2026 жыл алынды.');
  }
  MONTHS.forEach((aliases,index)=>{
    const re=new RegExp('(\\d{1,2})\\s*(?:'+aliases+')[а-яәіңғүұқөһ]*(?:\\s+(\\d{4}))?','gu');
    for(const m of text.matchAll(re)) {
      dates.push(`${m[2]||'2026'}-${String(index+1).padStart(2,'0')}-${m[1].padStart(2,'0')}`);
      if(!m[2]) notes.push('Жыл көрсетілмегендіктен 2026 жыл алынды.');
    }
  });
  if(dates.length===1) {
    const d=dates[0];
    if(validDate(d)&&d>=CALENDAR.min&&d<=CALENDAR.max) set('date',d);
    else problem('date','Күн 23.09.2026–31.12.2026 аралығында болуы керек; нақты күнді қайта жазыңыз.');
  } else if(dates.length>1) problem('date','Бір нақты күнді таңдаңыз, мысалы 15.10.2026.');
  if(/ертең|бүгін|завтра|сегодня|келесі апта|следующ.{0,5}недел/u.test(text)) problem('date','Салыстырмалы күнді түсіндірмеймін. Нақты күнді жазыңыз, мысалы 15.10.2026.');
  const duration=[...text.matchAll(/(-?\d+(?:[.,]\d+)?)\s*(?:сағат|сағ|час[а-я]*|ч\b)/gu)];
  if(duration.length===1){const v=Number(duration[0][1].replace(',','.'));if(v>=.5&&v<=1000&&v%.5===0)set('hours',v);else problem('hours','Ұзақтықты 0,5–1000 сағат аралығында жазыңыз.');}
  else if(duration.length>1)problem('hours','Бір ғана ұзақтықты көрсетіңіз.');
  const amounts=[];
  // Currency or scale identifies budget; dates and guest counts do not.
  const amountRegex=/(-?\d+(?:[ \u00a0]\d{3})*(?:[.,]\d+)?)\s*(миллион[а-я]*|млн|мың|тысяч[а-я]*|тыс\.?|k\b|к\b|₸|теңге|тенге|kzt)/gu;
  const toAmount=(n,u='')=>Number(n.replace(/[ \u00a0]/g,'').replace(',','.'))*(/млн|миллион/u.test(u)?1e6:/мың|тыс|тысяч|^[kк]$/u.test(u)?1000:1);
  for(const m of text.matchAll(amountRegex)) amounts.push(toAmount(m[1],m[2]));
  if(!amounts.length){
    const m=text.match(/бюджет(?:ім|іміз|і|ом|а)?\s*[:=—]?\s*(-?\d+(?:[ \u00a0]\d{3})*(?:[.,]\d+)?)/u);
    if(m)amounts.push(toAmount(m[1]));
    else if(q.budget===null && /^\s*\d+(?:[ \u00a0]\d{3})*\s*$/u.test(text))amounts.push(toAmount(text.trim()));
  }
  if(amounts.length===1){const v=amounts[0];if(Number.isInteger(v)&&v>=0&&v<=1e12)set('budget',v);else problem('budget','Бюджетті теңгемен, теріс емес бүтін сан ретінде жазыңыз.');}
  else if(amounts.length>1)problem('budget','Бір максималды бюджет көрсетіңіз.');
  // Never silently interpret alternative/negated requirements as positive matches.
  const negation=/(?:^|\s)не\s+(?:алмат|астан|ведущ|фотограф|свад|корпоратив)|(?:алматы|астана|жүргізуші|фотограф|той)\s+емес/u.test(text);
  if(negation)issues.expression='Терістеуді нақтылай алмаймын. Қалаған нұсқаны болымды сөйлеммен қайта жазыңыз.';
  else if(recognized)delete issues.expression;
  const missing=['city','date','format','category','budget'].filter(k=>q[k]===null);
  const warnings=['Тек көрсетілген қала, күн, формат, санат, бюджет, тіл және ұзақтық қолданылады. Стиль, қонақ саны және басқа тілектер сүзілмейді.'];
  return {criteria:q,issues,missing,recognized,notes:[...new Set(notes)],warnings,ready:!missing.length&&!Object.keys(issues).length&&recognized>0};
}
function startAssistant(data) {
  const form=document.getElementById('assistant-form'), input=document.getElementById('assistant-input');
  const apply=document.getElementById('assistant-apply'), log=document.getElementById('assistant-messages'), review=document.getElementById('assistant-review');
  let state={},pending=null;
  const say=(text,user=false)=>{log.append(element('p','assistant-message'+(user?' user-message':''),text));while(log.childElementCount>30)log.firstElementChild.remove();log.scrollTop=log.scrollHeight;};
  const reset=()=>{state={};pending=null;input.value='';log.replaceChildren();review.hidden=true;apply.disabled=true;say('Жаңа әңгіме. Қала, күн, формат, санат және бюджетіңізді жазыңыз.');input.focus();};
  form.addEventListener('submit',event=>{
    event.preventDefault();const text=input.value.trim();if(!text||text.length>2000)return;
    say(text,true);input.value='';state=parseLocalRequest(text,state);pending=null;
    const q=state.criteria;
    document.getElementById('assistant-chips').replaceChildren(...Object.entries(FIELD_NAMES).filter(([k])=>q[k]!==null).map(([k,name])=>element('span','query-chip',`${name}: ${k==='budget'?money(q[k]):k==='date'?displayDate(q[k]):k==='hours'?q[k]+' сағ':label(q[k])}`)));
    review.hidden=false;
    const messages=[...Object.values(state.issues),...state.notes];
    if(!state.recognized)messages.push('Сұраныстан жаңа шарт анықталмады. «Мысал» батырмасын пайдаланыңыз немесе төмендегі форманы толтырыңыз.');
    if(state.missing.length)messages.push('Нақтылау керек: '+state.missing.map(k=>FIELD_NAMES[k]).join(', ')+'.');
    if(state.ready){pending={...q,language:q.language||''};messages.push('Шарттарды анықтадым. Төмендегі мәндерді тексеріп, «Осы шарттармен іздеу» басыңыз.');}
    document.getElementById('assistant-missing').textContent=state.warnings.join(' ');
    say(messages.join('\n'));apply.disabled=!pending;
  });
  input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();form.requestSubmit();}});
  input.addEventListener('input',()=>{pending=null;apply.disabled=true;});
  apply.addEventListener('click',()=>{
    if(!pending)return;
    const q=pending;
    // Same validation and hard filters as the manual form.
    try{validateQuery(q);}catch(error){say(error.message);pending=null;apply.disabled=true;return;}
    for(const key of Object.keys(FIELD_NAMES))document.getElementById(key).value=q[key]??'';
    document.getElementById('search-form').requestSubmit();
    const result=recommend(data,q);
    say(result.items.length?`${result.eligibleCount} профиль шарттарға сай. Төменде ең көбі 3 ұсыныс және нақты түсіндірмелері көрсетілді.`:'Сәйкес ұсыныс жоқ. Төменде себептері көрсетілді; шарттарды өзгерте аласыз.');
    document.getElementById('results-heading').scrollIntoView({block:'start'});pending=null;apply.disabled=true;
  });
  document.getElementById('assistant-reset').addEventListener('click',reset);
  document.getElementById('assistant-example').addEventListener('click',()=>{reset();input.value='Алматыда 15 қазан 2026 корпоративке қазақша жүргізуші керек, бюджет 700 мың, 6 сағат.';input.focus();});
  document.querySelectorAll('[data-preset]').forEach(button=>button.addEventListener('click',()=>{
    reset();input.value=`${button.dataset.preset} мердігер керек.`;
    say('Үлгі дайын. Қала, нақты күн, мердігер санаты және бюджетіңізді қосып жазыңыз.');input.focus();
  }));
  document.getElementById('assistant-send').disabled=false;
}

async function init() {
  const form = document.getElementById("search-form");
  const status = document.getElementById("status");
  const retry = document.getElementById("retry-button");
  const results = document.getElementById("results");
  retry.hidden = true;
  status.className = "status";
  status.textContent = "Деректер жүктелуде…";
  results.setAttribute("aria-busy", "true");
  let data;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch("./hackathon-dataset-anonymized.jsonl", { cache: "no-cache", signal: controller.signal });
    if (!response.ok) throw new Error(`Деректер файлы жүктелмеді (HTTP ${response.status}).`);
    data = parseJSONL(await response.text());
    const fill = (id, values, initial, optional = false) => {
      const select = document.getElementById(id);
      if (!optional) select.replaceChildren();
      [...new Set(values)].sort(compareText).forEach(value => {
        select.add(new Option(label(value), value, value === initial, value === initial));
      });
    };
    fill("city", data.map(p => p.city), "Алматы");
    fill("category", data.flatMap(p => p.categories), "Ведущий");
    fill("format", data.flatMap(p => p.event_formats), "корпоратив");
    fill("language", data.flatMap(p => p.languages), "", true);
    document.getElementById("fields").disabled = false;
    document.getElementById("dataset-note").textContent = `${data.length} профиль · ${data.filter(p => p.synthetic).length} синтетикалық`;
  } catch (error) {
    status.className = "status error";
    status.textContent = error.name === "AbortError" ? "Жүктеу уақыты аяқталды. Байланысты тексеріп, қайта көріңіз." : "Каталогты жүктеу мүмкін болмады. Қайта жүктеп көріңіз. Мәселе қайталанса, README нұсқаулығы бойынша деректер файлын тексеріңіз.";
    if (error.message.startsWith("JSONL")) status.textContent += ` ${error.message}`;
    retry.hidden = false;
    retry.onclick = () => init();
    document.getElementById("results").setAttribute("aria-busy", "false");
    return;
  } finally {
    clearTimeout(timeout);
  }
  const formError = document.getElementById("form-error");
  const clearErrors = () => {
    formError.hidden = true;
    form.querySelectorAll('[aria-invalid="true"]').forEach(input => {
      input.removeAttribute("aria-invalid");
      input.removeAttribute("aria-errormessage");
    });
  };
  const run = (focusResult = false) => {
    clearErrors();
    const invalid = [...form.elements].find(input => input.willValidate && !input.validity.valid);
    if (invalid) {
      const messages = { city: "Қаланы таңдаңыз.", category: "Санатты таңдаңыз.", format: "Іс-шара түрін таңдаңыз.", date: "23.09.2026–31.12.2026 аралығындағы күнді енгізіңіз.", budget: "Бюджетті 0–1 000 000 000 000 аралығындағы бүтін санмен енгізіңіз.", hours: "Ұзақтықты 0,5–1000 сағат аралығында, 0,5 қадамымен енгізіңіз." };
      formError.textContent = messages[invalid.id] || "Белгіленген өрісті тексеріңіз.";
      formError.hidden = false;
      invalid.setAttribute("aria-invalid", "true");
      invalid.setAttribute("aria-errormessage", "form-error");
      invalid.focus();
      return;
    }
    const values = new FormData(form);
    const q = Object.fromEntries(values);
    q.budget = Number(q.budget);
    q.hours = q.hours.trim() === "" ? null : Number(q.hours);
    try {
      const recommendation=recommend(data,q);
      render(recommendation, q);
      renderExtras(data,recommendation,q);
      results.hidden = false;
      if (focusResult) document.getElementById("results-heading").focus({ preventScroll: !window.matchMedia("(max-width: 760px)").matches });
    }
    catch (error) { status.className = "status error"; status.textContent = error.message; }
    document.getElementById("results").setAttribute("aria-busy", "false");
  };
  form.addEventListener("submit", event => { event.preventDefault(); run(true); });
  form.addEventListener("reset", () => setTimeout(() => run(), 0));
  form.addEventListener("input", () => {
    for(const id of ['result-actions','comparison','suggestions','nearby-dates'])document.getElementById(id).hidden=true;
    clearErrors();
    results.hidden = true;
    document.getElementById("diagnostics").hidden = true;
    document.getElementById("query-summary").replaceChildren();
    document.getElementById("result-count").textContent = "— / 3";
    status.className = "status";
    status.textContent = "Шарттар өзгерді. Ұсыныстарды жаңарту үшін «Мердігерлерді табу» батырмасын басыңыз.";
  });
  run();
  startAssistant(data);
}

if (typeof document !== "undefined") {
  document.querySelectorAll("[data-dialog]").forEach(button => button.addEventListener("click", () => {
    document.getElementById(button.dataset.dialog).showModal();
  }));
  document.querySelectorAll("dialog").forEach(dialog => {
    dialog.querySelector(".dialog-close").addEventListener("click", () => dialog.close());
    dialog.addEventListener("click", event => {
      const rect = dialog.getBoundingClientRect();
      if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
    });
  });
  document.getElementById("method-link").addEventListener("click", () => {
    document.getElementById("how-it-works").open = true;
  });
  init();
}
if (typeof module !== "undefined" && module.exports) module.exports = { parseJSONL, recommend, scoreProfile, explanation, validateQuery, parseLocalRequest, findAlternatives };



